function equalSize = isequalsize(A, B)

equalSize = isequal(size(A), size(B));

end

